# OficiosYA — App Android (MVP gratuito)

App nativa en **Kotlin + Jetpack Compose**, con base de datos local (Room, sin
servidor ni costos). Incluye:

- Pantalla de inicio con buscador y grilla de categorías (10 oficios).
- Búsqueda de profesionales por oficio y filtro de zona.
- Perfil del profesional: foto (ícono), nombre, oficio, zona, descripción,
  trabajos realizados, calificación general y desglosada (calidad,
  responsabilidad, puntualidad, trato), nota de precios opcional y opiniones.
- Botón "CONTACTAR" que abre el marcador telefónico con el número cargado.
- Registro gratuito de profesionales y edición de su propio perfil.
- 4 profesionales de ejemplo precargados para que no arranque vacía.

## Cómo abrirlo y ejecutarlo

1. Instalá **Android Studio** (gratis): https://developer.android.com/studio
2. Abrí Android Studio → `File > Open` → seleccioná la carpeta `OficiosYA`
   que te compartí (la que contiene `settings.gradle.kts`).
3. Android Studio va a detectar que falta el *Gradle Wrapper* completo (el
   archivo binario `gradle-wrapper.jar` no se puede generar fuera de
   Android Studio) y te va a ofrecer **regenerarlo automáticamente** al
   sincronizar. Aceptá esa acción, o si no aparece sola, andá a:
   `File > Sync Project with Gradle Files`.
4. Esperá a que baje las dependencias (necesita internet la primera vez).
5. Conectá tu celular por USB con la **depuración USB activada**
   (`Ajustes > Opciones de desarrollador > Depuración USB`), o creá un
   emulador desde `Device Manager`.
6. Apretá el botón ▶ **Run** (verde) en Android Studio. La app se instala y
   abre sola en el dispositivo.

## Cómo generar el APK para instalar en tu teléfono

**Opción rápida (APK de prueba, para instalar manualmente):**

1. En Android Studio: `Build > Build App Bundle(s) / APK(s) > Build APK(s)`.
2. Cuando termine, aparece un aviso abajo a la derecha: "APK(s) generated
   successfully" → hacé clic en **locate** para encontrarlo.
3. El archivo queda en:
   `OficiosYA/app/build/outputs/apk/debug/app-debug.apk`
4. Copiá ese `app-debug.apk` a tu teléfono (por cable, WhatsApp, Drive, etc.)
   y abrilo desde el celular para instalarlo. Puede que tengas que habilitar
   "Instalar apps de orígenes desconocidos" la primera vez.

**Opción para publicar en Play Store (más adelante):**

`Build > Generate Signed Bundle / APK`, elegís `Android App Bundle`, creás
una *keystore* (clave de firma) siguiendo el asistente, y generás el
`.aab` para subir a Google Play Console (esto sí tiene un costo único de
registro de cuenta de Google Play, no de esta app).

## Estructura del proyecto

```
OficiosYA/
 ├─ app/src/main/java/com/oficiosya/app/
 │   ├─ MainActivity.kt          → punto de entrada
 │   ├─ AppViewModel.kt          → lógica de datos y búsqueda
 │   ├─ data/                    → modelos, Room (base local), repositorio
 │   ├─ navigation/              → navegación entre pantallas
 │   └─ ui/screens/              → las 5 pantallas + componentes (estrellas)
 └─ app/src/main/res/            → íconos, colores, nombre de la app
```

## Qué es y qué NO es este MVP (a propósito, para mantenerlo simple)

- **No tiene servidor**: los datos (profesionales, opiniones) se guardan
  localmente en cada celular con Room. Esto significa que un profesional
  registrado en tu teléfono **no lo va a ver otra persona** que instale la
  app en el suyo. Es ideal para probar el flujo completo y mostrarlo, pero
  para lanzarlo de verdad al público van a necesitar un backend compartido
  (por ejemplo Firebase, que tiene plan gratuito generoso, o un servidor
  propio con base de datos en la nube).
- El buscador de texto libre de la pantalla de inicio hoy lleva a la lista
  completa de profesionales (no filtra automáticamente por palabra clave);
  el filtro fino se hace por categoría y por zona en la pantalla de
  resultados. Se puede mejorar fácilmente más adelante.
- No hay login/contraseña: cualquiera que abra "Soy profesional" puede
  crear o editar el último perfil que creó en ese teléfono. Para producción
  conviene sumar autenticación (por ejemplo con Firebase Auth, gratis).
- El botón CONTACTAR abre el marcador con el número cargado (no llama
  automático), así el usuario confirma antes de llamar — más seguro y es
  el comportamiento esperado en Android.

## Próximo paso natural (cuando quieras ir más allá del MVP)

Migrar de Room (local) a **Firebase Firestore** (gratis hasta un volumen
alto de uso) para que los profesionales y sus calificaciones se vean en
todos los teléfonos. Si querés, te ayudo con ese paso cuando lo necesites.
