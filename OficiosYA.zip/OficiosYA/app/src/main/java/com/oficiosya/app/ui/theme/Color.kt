package com.oficiosya.app.ui.theme

import androidx.compose.ui.graphics.Color

val NaranjaPrincipal = Color(0xFFFF6D00)
val NaranjaOscuro = Color(0xFFE65100)
val AzulOscuro = Color(0xFF1A237E)
val VerdeExito = Color(0xFF2E7D32)
val AmarilloEstrella = Color(0xFFFFC107)
val FondoClaro = Color(0xFFF7F7FA)
val GrisTexto = Color(0xFF5F6368)
val SuperficieBlanca = Color(0xFFFFFFFF)
