package com.oficiosya.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.oficiosya.app.data.Profesional
import com.oficiosya.app.ui.theme.GrisTexto
import com.oficiosya.app.ui.theme.NaranjaPrincipal

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PantallaResultados(
    oficioInicial: String?,
    profesionales: List<Profesional>,
    onZonaCambiada: (String) -> Unit,
    onVolver: () -> Unit,
    onProfesionalSeleccionado: (Int) -> Unit
) {
    var zona by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text(oficioInicial ?: "Resultados") },
                navigationIcon = {
                    IconButton(onClick = onVolver) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Volver")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = zona,
                onValueChange = {
                    zona = it
                    onZonaCambiada(it)
                },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Filtrar por zona (ej: San Isidro)") },
                leadingIcon = { Icon(Icons.Filled.LocationOn, contentDescription = null) },
                shape = RoundedCornerShape(14.dp),
                singleLine = true
            )
            Spacer(Modifier.height(12.dp))

            if (profesionales.isEmpty()) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally
                ) {
                    Text(
                        "Todavía no hay profesionales para esta búsqueda.",
                        color = GrisTexto,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(profesionales) { profesional ->
                        TarjetaProfesional(profesional) {
                            onProfesionalSeleccionado(profesional.id)
                        }
                    }
                    item { Spacer(Modifier.height(16.dp)) }
                }
            }
        }
    }
}

@Composable
fun TarjetaProfesional(profesional: Profesional, onClic: () -> Unit) {
    Card(
        onClick = onClic,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(profesional.nombre, style = MaterialTheme.typography.titleMedium)
                Text(
                    "${profesional.oficio} · ${profesional.zona}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = GrisTexto
                )
                Spacer(Modifier.height(4.dp))
                Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    FilaDeEstrellas(puntaje = profesional.promedioGeneral, tamano = 16.dp)
                    Spacer(Modifier.width(6.dp))
                    Text(
                        if (profesional.cantidadOpiniones > 0)
                            "(${profesional.cantidadOpiniones})"
                        else "Sin calificaciones",
                        style = MaterialTheme.typography.bodyMedium,
                        color = GrisTexto
                    )
                }
                Text(
                    "${profesional.trabajosRealizados} trabajos realizados",
                    style = MaterialTheme.typography.bodyMedium,
                    color = NaranjaPrincipal,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}
