package com.oficiosya.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.oficiosya.app.data.AppDatabase
import com.oficiosya.app.data.Opinion
import com.oficiosya.app.data.Profesional
import com.oficiosya.app.data.Repositorio
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AppViewModel(application: Application) : AndroidViewModel(application) {

    private val repositorio: Repositorio by lazy {
        Repositorio(AppDatabase.obtenerInstancia(application, viewModelScope).profesionalDao())
    }

    // Filtros de la búsqueda actual
    val oficioFiltro = MutableStateFlow<String?>(null)
    val zonaFiltro = MutableStateFlow<String?>(null)

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val resultadosBusqueda: StateFlow<List<Profesional>> =
        combine(oficioFiltro, zonaFiltro) { oficio, zona -> oficio to zona }
            .flatMapLatest { (oficio, zona) -> repositorio.buscar(oficio, zona) }
            .stateIn(viewModelScope, kotlinx.coroutines.flow.SharingStarted.WhileSubscribed(5000), emptyList())

    // Id del profesional que soy yo mismo en este dispositivo (perfil propio, guardado en memoria simple)
    var miProfesionalId: Int? = null
        private set

    fun buscarPorOficio(oficio: String?) {
        oficioFiltro.value = oficio
    }

    fun actualizarZona(zona: String) {
        zonaFiltro.value = zona
    }

    fun obtenerProfesional(id: Int) = repositorio.obtenerPorId(id)

    fun obtenerOpiniones(id: Int) = repositorio.obtenerOpiniones(id)

    fun registrarOEditar(profesional: Profesional, alTerminar: (Int) -> Unit) {
        viewModelScope.launch {
            if (profesional.id == 0) {
                val nuevoId = repositorio.registrarProfesional(profesional)
                miProfesionalId = nuevoId.toInt()
                alTerminar(nuevoId.toInt())
            } else {
                repositorio.actualizarProfesional(profesional)
                miProfesionalId = profesional.id
                alTerminar(profesional.id)
            }
        }
    }

    fun calificar(
        profesional: Profesional,
        nombreCliente: String,
        comentario: String,
        calidad: Int,
        responsabilidad: Int,
        puntualidad: Int,
        trato: Int
    ) {
        viewModelScope.launch {
            repositorio.calificar(
                profesional,
                Opinion(
                    profesionalId = profesional.id,
                    nombreCliente = nombreCliente,
                    comentario = comentario,
                    calidad = calidad,
                    responsabilidad = responsabilidad,
                    puntualidad = puntualidad,
                    trato = trato
                )
            )
        }
    }
}
