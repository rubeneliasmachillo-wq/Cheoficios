package com.oficiosya.app.data

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Carpenter
import androidx.compose.material.icons.filled.Construction
import androidx.compose.material.icons.filled.Fence
import androidx.compose.material.icons.filled.Handyman
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Plumbing
import androidx.compose.material.icons.filled.Roofing
import androidx.compose.material.icons.filled.Yard
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.room.Entity
import androidx.room.PrimaryKey

/** Representa un oficio/categoría, con su ícono para la grilla de inicio. */
data class Oficio(
    val nombre: String,
    val icono: ImageVector
)

val listaDeOficios = listOf(
    Oficio("Albañil", Icons.Filled.Construction),
    Oficio("Electricista", Icons.Filled.Bolt),
    Oficio("Plomero", Icons.Filled.Plumbing),
    Oficio("Gasista", Icons.Filled.LocalFireDepartment),
    Oficio("Herrero", Icons.Filled.Fence),
    Oficio("Carpintero", Icons.Filled.Carpenter),
    Oficio("Pintor", Icons.Filled.Brush),
    Oficio("Techista", Icons.Filled.Roofing),
    Oficio("Jardinero", Icons.Filled.Yard),
    Oficio("Otros oficios", Icons.Filled.Handyman)
)

/**
 * Un profesional registrado en la app.
 * Las calificaciones se guardan promediadas (0f si todavía no tiene ninguna).
 */
@Entity(tableName = "profesionales")
data class Profesional(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val nombre: String,
    val oficio: String,
    val zona: String,
    val telefono: String,
    val descripcion: String,
    val notaPrecios: String = "",
    val fotoUrl: String = "",
    val trabajosRealizados: Int = 0,
    val promedioCalidad: Float = 0f,
    val promedioResponsabilidad: Float = 0f,
    val promedioPuntualidad: Float = 0f,
    val promedioTrato: Float = 0f,
    val cantidadOpiniones: Int = 0
) {
    val promedioGeneral: Float
        get() = if (cantidadOpiniones == 0) 0f else
            (promedioCalidad + promedioResponsabilidad + promedioPuntualidad + promedioTrato) / 4f
}

/** Una opinión/calificación individual dejada por un cliente. */
@Entity(tableName = "opiniones")
data class Opinion(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val profesionalId: Int,
    val nombreCliente: String,
    val comentario: String,
    val calidad: Int,
    val responsabilidad: Int,
    val puntualidad: Int,
    val trato: Int
)
