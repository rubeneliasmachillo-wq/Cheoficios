package com.oficiosya.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Row
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.oficiosya.app.ui.theme.AmarilloEstrella

/**
 * Muestra 5 estrellas. Si onEstrellaClic es null, es solo lectura (para mostrar un promedio).
 * Si se pasa, permite tocar una estrella para calificar (1 a 5).
 */
@Composable
fun FilaDeEstrellas(
    puntaje: Float,
    tamano: androidx.compose.ui.unit.Dp = 20.dp,
    onEstrellaClic: ((Int) -> Unit)? = null
) {
    Row {
        for (i in 1..5) {
            val llena = i <= kotlin.math.round(puntaje)
            Icon(
                imageVector = if (llena) Icons.Filled.Star else Icons.Filled.StarBorder,
                contentDescription = null,
                tint = AmarilloEstrella,
                modifier = Modifier
                    .size(tamano)
                    .then(
                        if (onEstrellaClic != null) Modifier.clickable { onEstrellaClic(i) }
                        else Modifier
                    )
            )
        }
    }
}
