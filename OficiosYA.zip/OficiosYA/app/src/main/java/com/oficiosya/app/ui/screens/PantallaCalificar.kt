package com.oficiosya.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PantallaCalificar(
    nombreProfesional: String,
    onVolver: () -> Unit,
    onEnviar: (nombreCliente: String, comentario: String, calidad: Int, responsabilidad: Int, puntualidad: Int, trato: Int) -> Unit
) {
    var nombreCliente by remember { mutableStateOf("") }
    var comentario by remember { mutableStateOf("") }
    var calidad by remember { mutableIntStateOf(5) }
    var responsabilidad by remember { mutableIntStateOf(5) }
    var puntualidad by remember { mutableIntStateOf(5) }
    var trato by remember { mutableIntStateOf(5) }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("Calificar a $nombreProfesional") },
                navigationIcon = {
                    IconButton(onClick = onVolver) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Volver")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            OutlinedTextField(
                value = nombreCliente,
                onValueChange = { nombreCliente = it },
                label = { Text("Tu nombre") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            CategoriaCalificable("Calidad del trabajo", calidad) { calidad = it }
            CategoriaCalificable("Responsabilidad", responsabilidad) { responsabilidad = it }
            CategoriaCalificable("Puntualidad", puntualidad) { puntualidad = it }
            CategoriaCalificable("Trato", trato) { trato = it }

            OutlinedTextField(
                value = comentario,
                onValueChange = { comentario = it },
                label = { Text("Comentario (opcional)") },
                modifier = Modifier.fillMaxWidth(),
                minLines = 3
            )

            Button(
                onClick = {
                    onEnviar(
                        nombreCliente.ifBlank { "Cliente anónimo" },
                        comentario, calidad, responsabilidad, puntualidad, trato
                    )
                },
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(14.dp)
            ) {
                Text("ENVIAR CALIFICACIÓN", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun CategoriaCalificable(nombre: String, valor: Int, onCambio: (Int) -> Unit) {
    Column {
        Text(nombre, style = MaterialTheme.typography.bodyLarge)
        FilaDeEstrellas(puntaje = valor.toFloat(), tamano = 30.dp, onEstrellaClic = onCambio)
    }
}
