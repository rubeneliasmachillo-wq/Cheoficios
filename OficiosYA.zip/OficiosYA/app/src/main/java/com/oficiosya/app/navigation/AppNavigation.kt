package com.oficiosya.app.navigation

import android.content.Intent
import android.net.Uri
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.oficiosya.app.AppViewModel
import com.oficiosya.app.ui.screens.PantallaCalificar
import com.oficiosya.app.ui.screens.PantallaInicio
import com.oficiosya.app.ui.screens.PantallaPerfil
import com.oficiosya.app.ui.screens.PantallaRegistro
import com.oficiosya.app.ui.screens.PantallaResultados

private object Rutas {
    const val INICIO = "inicio"
    const val RESULTADOS = "resultados/{oficio}"
    const val PERFIL = "perfil/{id}"
    const val REGISTRO = "registro"
    const val EDICION = "edicion/{id}"
    const val CALIFICAR = "calificar/{id}"
}

@Composable
fun AppNavigation() {
    val navController = rememberNavController()
    val viewModel: AppViewModel = viewModel()
    val contexto = LocalContext.current

    NavHost(navController = navController, startDestination = Rutas.INICIO) {

        composable(Rutas.INICIO) {
            PantallaInicio(
                onBuscar = { texto ->
                    viewModel.buscarPorOficio(null)
                    viewModel.actualizarZona("")
                    navController.navigate("resultados/${Uri.encode(texto.ifBlank { "Todos" })}")
                },
                onOficioSeleccionado = { oficio ->
                    viewModel.buscarPorOficio(oficio)
                    navController.navigate("resultados/${Uri.encode(oficio)}")
                },
                onRegistrarme = { navController.navigate(Rutas.REGISTRO) }
            )
        }

        composable(
            route = Rutas.RESULTADOS,
            arguments = listOf(navArgument("oficio") { type = NavType.StringType })
        ) { entrada ->
            val oficio = entrada.arguments?.getString("oficio")
            val resultados by viewModel.resultadosBusqueda.collectAsState()
            PantallaResultados(
                oficioInicial = oficio,
                profesionales = resultados,
                onZonaCambiada = { viewModel.actualizarZona(it) },
                onVolver = { navController.popBackStack() },
                onProfesionalSeleccionado = { id -> navController.navigate("perfil/$id") }
            )
        }

        composable(
            route = Rutas.PERFIL,
            arguments = listOf(navArgument("id") { type = NavType.IntType })
        ) { entrada ->
            val id = entrada.arguments?.getInt("id") ?: return@composable
            val profesional by viewModel.obtenerProfesional(id).collectAsState(initial = null)
            val opiniones by viewModel.obtenerOpiniones(id).collectAsState(initial = emptyList())

            profesional?.let { prof ->
                PantallaPerfil(
                    profesional = prof,
                    opiniones = opiniones,
                    esMiPerfil = viewModel.miProfesionalId == id,
                    onVolver = { navController.popBackStack() },
                    onContactar = {
                        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${prof.telefono}"))
                        contexto.startActivity(intent)
                    },
                    onEditar = { navController.navigate("edicion/$id") },
                    onCalificar = { navController.navigate("calificar/$id") }
                )
            }
        }

        composable(Rutas.REGISTRO) {
            PantallaRegistro(
                profesionalExistente = null,
                onVolver = { navController.popBackStack() },
                onGuardar = { profesional ->
                    viewModel.registrarOEditar(profesional) { id ->
                        navController.popBackStack()
                        navController.navigate("perfil/$id")
                    }
                }
            )
        }

        composable(
            route = Rutas.EDICION,
            arguments = listOf(navArgument("id") { type = NavType.IntType })
        ) { entrada ->
            val id = entrada.arguments?.getInt("id") ?: return@composable
            val profesional by viewModel.obtenerProfesional(id).collectAsState(initial = null)
            profesional?.let { prof ->
                PantallaRegistro(
                    profesionalExistente = prof,
                    onVolver = { navController.popBackStack() },
                    onGuardar = { actualizado ->
                        viewModel.registrarOEditar(actualizado) {
                            navController.popBackStack()
                        }
                    }
                )
            }
        }

        composable(
            route = Rutas.CALIFICAR,
            arguments = listOf(navArgument("id") { type = NavType.IntType })
        ) { entrada ->
            val id = entrada.arguments?.getInt("id") ?: return@composable
            val profesional by viewModel.obtenerProfesional(id).collectAsState(initial = null)
            profesional?.let { prof ->
                PantallaCalificar(
                    nombreProfesional = prof.nombre,
                    onVolver = { navController.popBackStack() },
                    onEnviar = { nombreCliente, comentario, calidad, responsabilidad, puntualidad, trato ->
                        viewModel.calificar(prof, nombreCliente, comentario, calidad, responsabilidad, puntualidad, trato)
                        navController.popBackStack()
                    }
                )
            }
        }
    }
}
