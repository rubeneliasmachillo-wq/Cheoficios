package com.oficiosya.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ProfesionalDao {

    @Query("SELECT * FROM profesionales ORDER BY promedioCalidad DESC")
    fun obtenerTodos(): Flow<List<Profesional>>

    @Query("""
        SELECT * FROM profesionales
        WHERE (:oficio IS NULL OR oficio = :oficio)
        AND (:zona IS NULL OR zona LIKE '%' || :zona || '%')
        ORDER BY promedioCalidad DESC
    """)
    fun buscar(oficio: String?, zona: String?): Flow<List<Profesional>>

    @Query("SELECT * FROM profesionales WHERE id = :id")
    fun obtenerPorId(id: Int): Flow<Profesional?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertar(profesional: Profesional): Long

    @Update
    suspend fun actualizar(profesional: Profesional)

    @Query("SELECT COUNT(*) FROM profesionales")
    suspend fun contar(): Int

    @Query("SELECT * FROM opiniones WHERE profesionalId = :profesionalId ORDER BY id DESC")
    fun obtenerOpiniones(profesionalId: Int): Flow<List<Opinion>>

    @Insert
    suspend fun insertarOpinion(opinion: Opinion)
}
