package com.oficiosya.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(entities = [Profesional::class, Opinion::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {

    abstract fun profesionalDao(): ProfesionalDao

    companion object {
        @Volatile
        private var INSTANCIA: AppDatabase? = null

        fun obtenerInstancia(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCIA ?: synchronized(this) {
                val instancia = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "oficiosya_db"
                ).build()
                INSTANCIA = instancia
                scope.launch(Dispatchers.IO) {
                    sembrarDatosDeEjemplo(instancia.profesionalDao())
                }
                instancia
            }
        }

        // Carga algunos profesionales de ejemplo la primera vez que arranca la app,
        // para que la pantalla no quede vacía. Se puede borrar sin problema.
        private suspend fun sembrarDatosDeEjemplo(dao: ProfesionalDao) {
            if (dao.contar() > 0) return
            val ejemplos = listOf(
                Profesional(
                    nombre = "Carlos Fernández",
                    oficio = "Electricista",
                    zona = "San Isidro",
                    telefono = "1122334455",
                    descripcion = "Instalaciones eléctricas domiciliarias, tableros y reparaciones urgentes.",
                    notaPrecios = "Visita/diagnóstico: desde $8.000. Presupuesto sin cargo.",
                    trabajosRealizados = 42,
                    promedioCalidad = 4.8f,
                    promedioResponsabilidad = 4.7f,
                    promedioPuntualidad = 4.5f,
                    promedioTrato = 4.9f,
                    cantidadOpiniones = 18
                ),
                Profesional(
                    nombre = "Mirta Gómez",
                    oficio = "Pintor",
                    zona = "Vicente López",
                    telefono = "1133445566",
                    descripcion = "Pintura interior y exterior, arreglo de humedad y empapelado.",
                    notaPrecios = "Precio por m² a convenir según superficie.",
                    trabajosRealizados = 27,
                    promedioCalidad = 4.6f,
                    promedioResponsabilidad = 4.6f,
                    promedioPuntualidad = 4.2f,
                    promedioTrato = 4.8f,
                    cantidadOpiniones = 11
                ),
                Profesional(
                    nombre = "Roberto Díaz",
                    oficio = "Plomero",
                    zona = "Tigre",
                    telefono = "1144556677",
                    descripcion = "Destapaciones, pérdidas de agua y colocación de sanitarios.",
                    notaPrecios = "",
                    trabajosRealizados = 65,
                    promedioCalidad = 4.4f,
                    promedioResponsabilidad = 4.3f,
                    promedioPuntualidad = 4.0f,
                    promedioTrato = 4.5f,
                    cantidadOpiniones = 24
                ),
                Profesional(
                    nombre = "Julián Torres",
                    oficio = "Albañil",
                    zona = "San Isidro",
                    telefono = "1155667788",
                    descripcion = "Refacciones, construcción en seco y ampliaciones.",
                    notaPrecios = "Presupuesto sin cargo a domicilio.",
                    trabajosRealizados = 33,
                    promedioCalidad = 4.9f,
                    promedioResponsabilidad = 4.8f,
                    promedioPuntualidad = 4.7f,
                    promedioTrato = 4.9f,
                    cantidadOpiniones = 15
                )
            )
            ejemplos.forEach { dao.insertar(it) }
        }
    }
}
