package com.oficiosya.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material3.Button
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.oficiosya.app.data.Profesional
import com.oficiosya.app.data.listaDeOficios

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PantallaRegistro(
    profesionalExistente: Profesional?,
    onVolver: () -> Unit,
    onGuardar: (Profesional) -> Unit
) {
    var nombre by remember { mutableStateOf(profesionalExistente?.nombre ?: "") }
    var oficio by remember { mutableStateOf(profesionalExistente?.oficio ?: listaDeOficios.first().nombre) }
    var zona by remember { mutableStateOf(profesionalExistente?.zona ?: "") }
    var telefono by remember { mutableStateOf(profesionalExistente?.telefono ?: "") }
    var descripcion by remember { mutableStateOf(profesionalExistente?.descripcion ?: "") }
    var notaPrecios by remember { mutableStateOf(profesionalExistente?.notaPrecios ?: "") }
    var menuOficioAbierto by remember { mutableStateOf(false) }

    val esEdicion = profesionalExistente != null

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text(if (esEdicion) "Editar mi perfil" else "Registro de profesional") },
                navigationIcon = {
                    IconButton(onClick = onVolver) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Volver")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                "El registro es 100% gratuito. Completá tus datos para que los clientes te encuentren.",
                style = androidx.compose.material3.MaterialTheme.typography.bodyMedium
            )

            OutlinedTextField(
                value = nombre,
                onValueChange = { nombre = it },
                label = { Text("Nombre y apellido") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            Column {
                OutlinedTextField(
                    value = oficio,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Oficio") },
                    trailingIcon = {
                        IconButton(onClick = { menuOficioAbierto = true }) {
                            Icon(Icons.Filled.ArrowDropDown, contentDescription = null)
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                )
                DropdownMenu(
                    expanded = menuOficioAbierto,
                    onDismissRequest = { menuOficioAbierto = false }
                ) {
                    listaDeOficios.forEach { o ->
                        DropdownMenuItem(
                            text = { Text(o.nombre) },
                            onClick = {
                                oficio = o.nombre
                                menuOficioAbierto = false
                            }
                        )
                    }
                }
            }

            OutlinedTextField(
                value = zona,
                onValueChange = { zona = it },
                label = { Text("Zona / barrio donde trabajás") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            OutlinedTextField(
                value = telefono,
                onValueChange = { telefono = it },
                label = { Text("Teléfono de contacto") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                    keyboardType = androidx.compose.ui.text.input.KeyboardType.Phone
                )
            )

            OutlinedTextField(
                value = descripcion,
                onValueChange = { descripcion = it },
                label = { Text("Descripción breve de tu trabajo") },
                modifier = Modifier.fillMaxWidth(),
                minLines = 3
            )

            OutlinedTextField(
                value = notaPrecios,
                onValueChange = { notaPrecios = it },
                label = { Text("Nota de precios (opcional)") },
                placeholder = { Text("Ej: Visita sin cargo, presupuesto a convenir") },
                modifier = Modifier.fillMaxWidth(),
                minLines = 2
            )

            Button(
                onClick = {
                    val actualizado = (profesionalExistente ?: Profesional(
                        nombre = "", oficio = "", zona = "", telefono = "", descripcion = ""
                    )).copy(
                        nombre = nombre,
                        oficio = oficio,
                        zona = zona,
                        telefono = telefono,
                        descripcion = descripcion,
                        notaPrecios = notaPrecios
                    )
                    onGuardar(actualizado)
                },
                enabled = nombre.isNotBlank() && zona.isNotBlank() && telefono.isNotBlank(),
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(14.dp)
            ) {
                Text(if (esEdicion) "GUARDAR CAMBIOS" else "REGISTRARME GRATIS", fontWeight = FontWeight.Bold)
            }
        }
    }
}
