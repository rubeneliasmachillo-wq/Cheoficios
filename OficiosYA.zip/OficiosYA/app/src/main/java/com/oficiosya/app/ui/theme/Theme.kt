package com.oficiosya.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val ColorSchemeClaro = lightColorScheme(
    primary = NaranjaPrincipal,
    onPrimary = SuperficieBlanca,
    secondary = AzulOscuro,
    background = FondoClaro,
    surface = SuperficieBlanca,
    onBackground = AzulOscuro,
    onSurface = AzulOscuro
)

private val ColorSchemeOscuro = darkColorScheme(
    primary = NaranjaPrincipal,
    onPrimary = SuperficieBlanca,
    secondary = AzulOscuro,
    background = Color4Dark,
    surface = Color4DarkSurface
)

private val Color4Dark = androidx.compose.ui.graphics.Color(0xFF121218)
private val Color4DarkSurface = androidx.compose.ui.graphics.Color(0xFF1E1E26)

@Composable
fun OficiosYATheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) ColorSchemeOscuro else ColorSchemeClaro
    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
