package com.oficiosya.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.oficiosya.app.data.Opinion
import com.oficiosya.app.data.Profesional
import com.oficiosya.app.ui.theme.AzulOscuro
import com.oficiosya.app.ui.theme.GrisTexto
import com.oficiosya.app.ui.theme.NaranjaPrincipal
import com.oficiosya.app.ui.theme.VerdeExito

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PantallaPerfil(
    profesional: Profesional,
    opiniones: List<Opinion>,
    esMiPerfil: Boolean,
    onVolver: () -> Unit,
    onContactar: () -> Unit,
    onEditar: () -> Unit,
    onCalificar: () -> Unit
) {
    Box(modifier = Modifier.fillMaxSize()) {
    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text(profesional.nombre) },
                navigationIcon = {
                    IconButton(onClick = onVolver) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Volver")
                    }
                },
                actions = {
                    if (esMiPerfil) {
                        IconButton(onClick = onEditar) {
                            Icon(Icons.Filled.Edit, contentDescription = "Editar perfil")
                        }
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .background(NaranjaPrincipal.copy(alpha = 0.15f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Filled.Person,
                            contentDescription = null,
                            tint = NaranjaPrincipal,
                            modifier = Modifier.size(40.dp)
                        )
                    }
                    Spacer(Modifier.width(16.dp))
                    Column {
                        Text(profesional.nombre, style = MaterialTheme.typography.titleLarge)
                        Text(
                            "${profesional.oficio} · ${profesional.zona}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = GrisTexto
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            FilaDeEstrellas(puntaje = profesional.promedioGeneral)
                            Spacer(Modifier.width(6.dp))
                            Text("(${profesional.cantidadOpiniones})", color = GrisTexto)
                        }
                    }
                }
            }

            item {
                Text(
                    "${profesional.trabajosRealizados} trabajos realizados",
                    color = VerdeExito,
                    fontWeight = FontWeight.Bold
                )
            }

            if (profesional.descripcion.isNotBlank()) {
                item {
                    Column {
                        Text("Sobre mí", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(4.dp))
                        Text(profesional.descripcion, style = MaterialTheme.typography.bodyLarge)
                    }
                }
            }

            if (profesional.notaPrecios.isNotBlank()) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = AzulOscuro.copy(alpha = 0.06f)),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Column(Modifier.padding(14.dp)) {
                            Text(
                                "Nota de precios (orientativa)",
                                style = MaterialTheme.typography.titleMedium,
                                color = AzulOscuro
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(profesional.notaPrecios, style = MaterialTheme.typography.bodyLarge)
                        }
                    }
                }
            }

            item {
                Column {
                    Text("Calificación detallada", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    FilaDeCategoria("Calidad del trabajo", profesional.promedioCalidad)
                    FilaDeCategoria("Responsabilidad", profesional.promedioResponsabilidad)
                    FilaDeCategoria("Puntualidad", profesional.promedioPuntualidad)
                    FilaDeCategoria("Trato", profesional.promedioTrato)
                }
            }

            if (!esMiPerfil) {
                item {
                    androidx.compose.material3.OutlinedButton(
                        onClick = onCalificar,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Dejar una calificación")
                    }
                }
            }

            item {
                HorizontalDivider()
                Text(
                    "Opiniones (${opiniones.size})",
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(top = 12.dp)
                )
            }

            if (opiniones.isEmpty()) {
                item {
                    Text("Todavía no tiene opiniones.", color = GrisTexto)
                }
            } else {
                items(opiniones) { opinion ->
                    Card(shape = RoundedCornerShape(12.dp)) {
                        Column(Modifier.padding(12.dp)) {
                            Text(opinion.nombreCliente, fontWeight = FontWeight.SemiBold)
                            FilaDeEstrellas(
                                puntaje = (opinion.calidad + opinion.responsabilidad + opinion.puntualidad + opinion.trato) / 4f,
                                tamano = 14.dp
                            )
                            if (opinion.comentario.isNotBlank()) {
                                Spacer(Modifier.height(4.dp))
                                Text(opinion.comentario, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }
                }
            }

            item { Spacer(Modifier.height(70.dp)) }
        }
    }

    if (!esMiPerfil) {
        Button(
            onClick = onContactar,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(20.dp)
                .height(56.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = VerdeExito)
        ) {
            Icon(Icons.Filled.Call, contentDescription = null, tint = Color.White)
            Spacer(Modifier.width(8.dp))
            Text("CONTACTAR", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Color.White)
        }
    }
    }
}

@Composable
private fun FilaDeCategoria(nombre: String, valor: Float) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(nombre, style = MaterialTheme.typography.bodyLarge)
        FilaDeEstrellas(puntaje = valor, tamano = 16.dp)
    }
}
