package com.oficiosya.app.data

import kotlinx.coroutines.flow.Flow

class Repositorio(private val dao: ProfesionalDao) {

    fun obtenerTodos(): Flow<List<Profesional>> = dao.obtenerTodos()

    fun buscar(oficio: String?, zona: String?): Flow<List<Profesional>> =
        dao.buscar(oficio?.takeIf { it.isNotBlank() }, zona?.takeIf { it.isNotBlank() })

    fun obtenerPorId(id: Int): Flow<Profesional?> = dao.obtenerPorId(id)

    fun obtenerOpiniones(profesionalId: Int): Flow<List<Opinion>> = dao.obtenerOpiniones(profesionalId)

    suspend fun registrarProfesional(profesional: Profesional): Long = dao.insertar(profesional)

    suspend fun actualizarProfesional(profesional: Profesional) = dao.actualizar(profesional)

    /** Agrega una opinión nueva y recalcula los promedios del profesional. */
    suspend fun calificar(profesional: Profesional, opinion: Opinion) {
        dao.insertarOpinion(opinion)
        val n = profesional.cantidadOpiniones
        val nuevoN = n + 1
        val actualizado = profesional.copy(
            promedioCalidad = ((profesional.promedioCalidad * n) + opinion.calidad) / nuevoN,
            promedioResponsabilidad = ((profesional.promedioResponsabilidad * n) + opinion.responsabilidad) / nuevoN,
            promedioPuntualidad = ((profesional.promedioPuntualidad * n) + opinion.puntualidad) / nuevoN,
            promedioTrato = ((profesional.promedioTrato * n) + opinion.trato) / nuevoN,
            cantidadOpiniones = nuevoN,
            trabajosRealizados = profesional.trabajosRealizados + 1
        )
        dao.actualizar(actualizado)
    }
}
